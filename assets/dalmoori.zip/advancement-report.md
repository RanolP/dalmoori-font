## Advancement Report

Comparison between 3c1bb94 (Version 0.100 b112) and c2dde8b (Version 0.100 b2).

### Summary

- Basic Latin: 95/128 (no changes)
- Hangul Compatibility Jamo: 51/96 (no changes)
- Hangul Syllables: 11172/11184 (no changes)

### Details

#### Hangul Syllables

**Changed**: 력 (U+B825), 렦 (U+B826), 렧 (U+B827), 련 (U+B828), 렩 (U+B829), 렫 (U+B82B), 렴 (U+B834), 렷 (U+B837), 렸 (U+B838), 령 (U+B839), 렺 (U+B83A), 렻 (U+B83B), 렾 (U+B83E), 렿 (U+B83F), 롁 (U+B841), 롂 (U+B842), 롃 (U+B843), 롄 (U+B844), 롅 (U+B845), 롆 (U+B846), 롇 (U+B847), 롐 (U+B850), 롓 (U+B853), 롔 (U+B854), 롕 (U+B855), 롖 (U+B856), 롚 (U+B85A), 촉 (U+CD09), 촊 (U+CD0A), 촋 (U+CD0B), 촌 (U+CD0C), 촛 (U+CD1B), 촜 (U+CD1C), 쵹 (U+CD79), 쵺 (U+CD7A), 쵻 (U+CD7B), 쵼 (U+CD7C), 춋 (U+CD8B), 춌 (U+CD8C), 축 (U+CD95), 춖 (U+CD96), 춗 (U+CD97), 춘 (U+CD98), 춧 (U+CDA7), 츅 (U+CE05), 츆 (U+CE06), 츇 (U+CE07), 츈 (U+CE08), 츗 (U+CE17)