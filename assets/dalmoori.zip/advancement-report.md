## Advancement Report

Comparison between c3e94ec (Version 0.100) and 4b4b922 (Version 0.100).

### Summary

- Basic Latin: 95/128 (no changes)
- Hangul Compatibility Jamo: 51/96 (no changes)
- Hangul Syllables: 11172/11184 (no changes)

### Details

#### Hangul Syllables

**Changed**: 력 (U+B825), 렦 (U+B826), 렧 (U+B827), 련 (U+B828), 렩 (U+B829), 렫 (U+B82B), 렴 (U+B834), 렷 (U+B837), 렸 (U+B838), 령 (U+B839), 렺 (U+B83A), 렻 (U+B83B), 렾 (U+B83E), 렿 (U+B83F), 롁 (U+B841), 롂 (U+B842), 롃 (U+B843), 롄 (U+B844), 롅 (U+B845), 롆 (U+B846), 롇 (U+B847), 롐 (U+B850), 롓 (U+B853), 롔 (U+B854), 롕 (U+B855), 롖 (U+B856), 롚 (U+B85A)